//app.js
App({
  onLaunch: function () {
  },
  globalData: {
    lat_ask:'',
    lon_ask:'',
  }
})
